(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab2-tab2-module"],{

/***/ "EGAO":
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWIyLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "JZ9U":
/*!***********************************!*\
  !*** ./src/app/tab2/tab2.page.ts ***!
  \***********************************/
/*! exports provided: Tab2Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab2Page", function() { return Tab2Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_tab2_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./tab2.page.html */ "e9nj");
/* harmony import */ var _tab2_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab2.page.scss */ "EGAO");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _groceries_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../groceries.service */ "i4qo");
/* harmony import */ var _input_dialog_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../input-dialog.service */ "P/bC");
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "/XPu");








let Tab2Page = class Tab2Page {
    constructor(toastCtrl, alertController, dataService, inputDialogService, socialSharing) {
        this.toastCtrl = toastCtrl;
        this.alertController = alertController;
        this.dataService = dataService;
        this.inputDialogService = inputDialogService;
        this.socialSharing = socialSharing;
    }
    loadItems() {
        return this.dataService.getItems();
    }
    removeItem(item, index) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log("Removing Item - ", item, index);
            const toast = yield this.toastCtrl.create({
                message: 'Removing Item - ' + index + " ...",
                duration: 3000
            });
            toast.present();
            this.dataService.removeItem(index);
        });
    }
    shareItem(item, index) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log("Sharing Item - ", item, index);
            const toast = yield this.toastCtrl.create({
                message: 'Sharing Item - ' + index + " ...",
                duration: 3000
            });
            toast.present();
            let message = "Grocery Item - Name: " + item.name + " - Quantity: " + item.quantity;
            let subject = "Shared via Groceries app";
            this.socialSharing.share(message, subject).then(() => {
                // Sharing via email is possible
                console.log("Shared successfully!");
            }).catch((error) => {
                console.error("Error while sharing ", error);
            });
        });
    }
    editItem(item, index) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log("Edit Item - ", item, index);
            const toast = yield this.toastCtrl.create({
                message: 'Editing Item - ' + index + " ...",
                duration: 3000
            });
            toast.present();
            this.inputDialogService.showPrompt(item, index);
        });
    }
    addItem() {
        console.log("Adding Item");
        this.inputDialogService.showPrompt();
    }
};
Tab2Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _groceries_service__WEBPACK_IMPORTED_MODULE_5__["GroceriesService"] },
    { type: _input_dialog_service__WEBPACK_IMPORTED_MODULE_6__["InputDialogService"] },
    { type: _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_7__["SocialSharing"] }
];
Tab2Page = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-tab2',
        template: _raw_loader_tab2_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_tab2_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], Tab2Page);



/***/ }),

/***/ "P/bC":
/*!*****************************************!*\
  !*** ./src/app/input-dialog.service.ts ***!
  \*****************************************/
/*! exports provided: InputDialogService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputDialogService", function() { return InputDialogService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _groceries_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./groceries.service */ "i4qo");
/* harmony import */ var _grocery_grocery_item__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./grocery/grocery.item */ "z90B");





let InputDialogService = class InputDialogService {
    constructor(alertController, dataService) {
        this.alertController = alertController;
        this.dataService = dataService;
        console.log('Hello InputDialogService Provider');
    }
    showPrompt(item, index) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const prompt = yield this.alertController.create({
                header: item ? 'Edit Item' : 'Add Item',
                message: item ? "Please edit item..." : "Please enter item...",
                inputs: [
                    {
                        name: 'name',
                        placeholder: 'Name',
                        value: item ? item.name : null
                    },
                    {
                        name: 'quantity',
                        placeholder: 'Quantity',
                        value: item ? item.quantity : null
                    },
                    {
                        name: 'price',
                        placeholder: 'Price',
                        value: item ? item.price : null
                    },
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        handler: data => {
                            console.log('Cancel clicked');
                        }
                    },
                    {
                        text: 'Save',
                        handler: item => {
                            console.log('Saved clicked', item);
                            if (index !== undefined) {
                                this.dataService.editItem(new _grocery_grocery_item__WEBPACK_IMPORTED_MODULE_4__["GroceryItem"](item.name, item.quantity, item.price), index);
                            }
                            else {
                                this.dataService.addItem(new _grocery_grocery_item__WEBPACK_IMPORTED_MODULE_4__["GroceryItem"](item.name, item.quantity, item.price));
                            }
                        }
                    }
                ]
            });
            prompt.present();
        });
    }
};
InputDialogService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _groceries_service__WEBPACK_IMPORTED_MODULE_3__["GroceriesService"] }
];
InputDialogService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], InputDialogService);



/***/ }),

/***/ "TUkU":
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.module.ts ***!
  \*************************************/
/*! exports provided: Tab2PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab2PageModule", function() { return Tab2PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tab2.page */ "JZ9U");
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../explore-container/explore-container.module */ "qtYk");
/* harmony import */ var _tab2_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./tab2-routing.module */ "UDmF");








let Tab2PageModule = class Tab2PageModule {
};
Tab2PageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_6__["ExploreContainerComponentModule"],
            _tab2_routing_module__WEBPACK_IMPORTED_MODULE_7__["Tab2PageRoutingModule"]
        ],
        declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_5__["Tab2Page"]]
    })
], Tab2PageModule);



/***/ }),

/***/ "UDmF":
/*!*********************************************!*\
  !*** ./src/app/tab2/tab2-routing.module.ts ***!
  \*********************************************/
/*! exports provided: Tab2PageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab2PageRoutingModule", function() { return Tab2PageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tab2.page */ "JZ9U");




const routes = [
    {
        path: '',
        component: _tab2_page__WEBPACK_IMPORTED_MODULE_3__["Tab2Page"],
    }
];
let Tab2PageRoutingModule = class Tab2PageRoutingModule {
};
Tab2PageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], Tab2PageRoutingModule);



/***/ }),

/***/ "e9nj":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tab2/tab2.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <ion-title>\r\n      Groceries\r\n    </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content [fullscreen]=\"true\">\r\n  <ion-header collapse=\"condense\">\r\n    <ion-toolbar>\r\n      <ion-title size=\"large\">Groceries</ion-title>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n  <div class=\"container-fluid\">\r\n    <div class=\"row\">\r\n      <div class=\"col\">\r\n        <div class=\"alert alert-warning text-center\" role=\"alert\" *ngIf=\"loadItems().length === 0\">\r\n          No item available on the list!\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col\">\r\n        <ion-list>\r\n          <ion-item-sliding *ngFor=\"let item of loadItems(); let i = index\">\r\n            <ion-item>\r\n              <table class=\"table table-borderless\">\r\n                <thead>\r\n                <tr>\r\n                  <th class=\"w-25\">Name</th>\r\n                  <th class=\"w-25\">Quantity</th>\r\n                  <th class=\"w-25\">Price</th>\r\n                  <th class=\"w-25\">Total Cost</th>\r\n                </tr>\r\n                </thead>\r\n                <tbody>\r\n                <tr>\r\n                  <td class=\"w-25\">{{item.name}}</td>\r\n                  <td class=\"w-25\">{{item.quantity}}</td>\r\n                  <td class=\"w-25\">{{item.price}}</td>\r\n                  <td class=\"w-25\">{{item.formatTotalCost('en-US', 'currency', 'USD')}}</td>\r\n                </tr>\r\n                </tbody>\r\n              </table>\r\n            </ion-item>\r\n            <ion-item-options>\r\n              <button (click)=\"editItem(item, i)\" color=\"primary\">\r\n                <ion-icon name=\"create\"></ion-icon>\r\n                Edit\r\n              </button>\r\n              <button (click)=\"shareItem(item, i)\" color=\"light\">\r\n                <ion-icon name=\"share\"></ion-icon>\r\n                Share\r\n              </button>\r\n              <button (click)=\"removeItem(item, i)\" color=\"secondary\">\r\n                <ion-icon name=\"trash\"></ion-icon>\r\n                Done\r\n              </button>\r\n            </ion-item-options>\r\n          </ion-item-sliding>\r\n        </ion-list>\r\n\r\n        <ion-fab vertical=\"bottom\" horizontal=\"end\">\r\n          <button (click)=\"addItem()\">\r\n            <ion-icon name=\"add-outline\"></ion-icon>\r\n          </button>\r\n        </ion-fab>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "i4qo":
/*!**************************************!*\
  !*** ./src/app/groceries.service.ts ***!
  \**************************************/
/*! exports provided: GroceriesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroceriesService", function() { return GroceriesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


let GroceriesService = class GroceriesService {
    constructor() {
        this.items = [];
        console.log('Hello GroceriesServiceProvider');
    }
    getItems() {
        return this.items;
    }
    removeItem(index) {
        this.items.splice(index, 1);
    }
    addItem(item) {
        this.items.push(item);
    }
    editItem(item, index) {
        this.items[index] = item;
    }
};
GroceriesService.ctorParameters = () => [];
GroceriesService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], GroceriesService);



/***/ }),

/***/ "z90B":
/*!*****************************************!*\
  !*** ./src/app/grocery/grocery.item.ts ***!
  \*****************************************/
/*! exports provided: GroceryItem */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroceryItem", function() { return GroceryItem; });
class GroceryItem {
    constructor(name, quantity, price) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
        this.totalCost = quantity * price;
    }
    /**
     * Formats the totalCost variable for the purposes of display
     * @param locale - 'en-US'
     * @param style - 'currency'
     * @param currency - 'USD'
     */
    formatTotalCost(locale, style, currency) {
        let formatter = new Intl.NumberFormat(locale, {
            style: style,
            currency: currency,
        });
        return formatter.format(this.totalCost);
    }
}


/***/ })

}]);
//# sourceMappingURL=tab2-tab2-module.js.map